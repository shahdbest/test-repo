package com.example.wiprologreg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Wipro93LoginregApplication {

	public static void main(String[] args) {
		SpringApplication.run(Wipro93LoginregApplication.class, args);
	}

}
