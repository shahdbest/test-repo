package com.example.wiprologreg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.wiprologreg.model.User;
import com.example.wiprologreg.model.UserAuth;
import com.example.wiprologreg.service.UserSerivice;

@RestController
@RequestMapping("users")
@CrossOrigin
public class UserController {

	@Autowired
	UserSerivice userService;
	
	@PostMapping 
	public ResponseEntity<User> saveUser(@RequestBody User user)
	{
		User savedUser= userService.saveUser(user);
		return new ResponseEntity<User>(savedUser,HttpStatus.OK);
		
	}
	
	@PostMapping("/login") 
	public ResponseEntity<User> login(@RequestBody UserAuth userAuth)
	{
		User savedUser= userService.findByEmailAndPassword(userAuth.getEmail(),userAuth.getPassword());
		return new ResponseEntity<User>(savedUser,HttpStatus.OK);
		
	}
	
	
	@GetMapping("forgotpass/{email}/{securityQuestion}/{securityAnswer}")
	public ResponseEntity<User> findByEmailAndSecurityQuestionAndSecurityAnswer(@PathVariable String email, @PathVariable String securityQuestion,@PathVariable String securityAnswer)
	{
		
		User user= userService.findByEmailAndSecurityQuestionAndSecurityAnswer(email, securityQuestion, securityAnswer);
		return new ResponseEntity<User>(user,HttpStatus.OK);
	}
	
	
	@PutMapping("resetpass")
	public ResponseEntity<User> resetPassword(@RequestBody User user)
	{
		
		User userUpdated= userService.resetPassword(user);
		return new ResponseEntity<User>(userUpdated,HttpStatus.OK);
	}
	
}
