package com.example.wiprologreg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Wipro93LoginregApplicationTests {

	@Test
	void contextLoads() {
	}

}
