import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-purchase',
  templateUrl: './purchase.component.html',
  styleUrls: ['./purchase.component.css']
})
export class PurchaseComponent implements OnInit {

  constructor(private userservice:UserService) { }

  ngOnInit(): void {
  
    this.token=localStorage.getItem('token');
    //console.log(token);
  
    this.getPurchaseService();
  }

  token='';
msg='';
  getPurchaseService()
  {
    this.userservice.getPurchaseService(this.token).subscribe(
data=>{
  this.msg=data;
  console.log(data)
},
error=>{
  console.log(error)
}

    )

  }

}
