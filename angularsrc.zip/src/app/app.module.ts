import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegComponent } from './reg/reg.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule} from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { ForgotpassComponent } from './forgotpass/forgotpass.component';
import { ForgotnewComponent } from './forgotnew/forgotnew.component';
import { ResetComponent } from './reset/reset.component';
import { MenuComponent } from './menu/menu.component';
import { PurchaseComponent } from './purchase/purchase.component'

@NgModule({
  declarations: [
    AppComponent,
    RegComponent,
    LoginComponent,
    ForgotpassComponent,
    ForgotnewComponent,
    ResetComponent,
    MenuComponent,
    PurchaseComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
