import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from 'src/user.model';
import { UserAuth } from 'src/userauth.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }


registerUser(user:User)
{
return  this.http.post<User>('http://localhost:1234/users',user);
}


loginUser(userAuth:UserAuth)
{
//return  this.http.post<any>('http://localhost:3333/user/na/login',userAuth,{responseType: 'text' as 'json'});
console.log(userAuth);
return  this.http.post<any>('http://localhost:1234/users/login',userAuth);
}



forgotPass(email:string,securityQuestion:string,securityAnswer:string)
{

return this.http.get<User>(`http://localhost:1234/users/forgotpass/${email}/${securityQuestion}/${securityAnswer}`)
}


getPurchaseService(token:string)
{
  let myToken='Bearer '+token;
  let headers=new HttpHeaders().set('Authorization',myToken);
return this.http.get<string>(`http://localhost:3333/purchaseservice/info`,{headers,responseType: 'test' as 'json'});
}



//http://localhost:3333/purchaseservice/info

resetPass(user:User)
{

  return this.http.put('http://localhost:1234/users/resetpass',user);
}


}
