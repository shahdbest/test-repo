import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ForgotnewComponent } from './forgotnew/forgotnew.component';
import { LoginComponent } from './login/login.component';
import { MenuComponent } from './menu/menu.component';
import { PurchaseComponent } from './purchase/purchase.component';
import { RegComponent } from './reg/reg.component';
import { ResetComponent } from './reset/reset.component';

const routes: Routes = [
  {path:'',redirectTo:'login',pathMatch:'full'},
{path:"reg",component:RegComponent},
{path:"login",component:LoginComponent},
{path:"forgotpass",component:ForgotnewComponent},
{path:"reset",component:ResetComponent},
{path:"menu",component:MenuComponent},
{path:"purchase",component:PurchaseComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
