export class UserAuth
{
email='';
password=''

}
