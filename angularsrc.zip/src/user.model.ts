export class User
{
userName=''
email='';
password=''
 cPassword=''
 securityQuestion=''
 securityAnswer=''
 address=''
 contact=0
 dob=''
 gender=''
//NEW CODE
 pic=''

}